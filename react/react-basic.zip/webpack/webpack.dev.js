module.exports = {
    mode: 'development',
    devServer: {
        hot: true,
        open: true
    },
    devtool: 'cheap-module-source-map'
}
